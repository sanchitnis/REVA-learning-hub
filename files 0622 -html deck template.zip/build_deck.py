#!/usr/bin/env python3
"""
build_deck.py — Generate a standalone interactive deck HTML file from
a markdown source, using deck-template.html as the visual chassis.

Usage:
    python3 build_deck.py <input.md> <output.html> [--template path/to/deck-template.html]

Markdown contract (see learning-deck-skill/REFERENCE.md for full detail):

    ---
    title: Full deck title shown in the browser tab and header chip
    short_title: Short title shown in the sidebar header
    author: Name shown under the short title and in the footer
    eyebrow: Small tag line above the title on slide 1 (optional)
    ---

    # Title Part One :: Accent Part Two

    Subtitle in italics goes on its own line wrapped in *asterisks*.

    Intro paragraph — plain text, becomes the slide's lead paragraph.

    ===bookmark===            (optional marker — see REFERENCE.md)

    ---

    ## Second Slide Title

    Body content for slide two. Plain paragraphs only in this minimal
    version; see REFERENCE.md for the supported block types.

This script is intentionally mechanical: it does not call any LLM, does
not invent content, and does not make design decisions. All visual
design is fixed by the template; all content comes verbatim from the
markdown. Re-running it on an edited markdown file regenerates the HTML
deterministically — safe to re-run for maintenance, never hand-patch
the generated HTML directly.
"""

import sys
import re
import argparse
from pathlib import Path


def parse_frontmatter(text):
    """Extract a --- ... --- YAML-ish frontmatter block. No external
    YAML dependency: only simple `key: value` lines are supported,
    which is all the deck metadata needs."""
    m = re.match(r'^---\s*\n(.*?)\n---\s*\n(.*)$', text, re.DOTALL)
    if not m:
        return {}, text
    raw, rest = m.group(1), m.group(2)
    meta = {}
    for line in raw.splitlines():
        line = line.strip()
        if not line or ':' not in line:
            continue
        key, _, val = line.partition(':')
        meta[key.strip()] = val.strip()
    return meta, rest


def split_slides(body):
    """Split the markdown body into slides on a line that is exactly
    `---` (a horizontal rule used here as the slide separator, distinct
    from the frontmatter delimiter which is already consumed)."""
    # Normalize line endings, then split on a standalone --- line.
    parts = re.split(r'\n-{3,}\n', '\n' + body.strip() + '\n')
    return [p.strip() for p in parts if p.strip()]


def extract_bookmark(slide_text):
    """A line containing only ===bookmark=== marks this slide for the
    bookmark icon in the sidebar instead of a number. Returns
    (is_bookmark, cleaned_text)."""
    is_bookmark = bool(re.search(r'^\s*===bookmark===\s*$', slide_text, re.MULTILINE))
    cleaned = re.sub(r'^\s*===bookmark===\s*$', '', slide_text, flags=re.MULTILINE)
    return is_bookmark, cleaned.strip()


def render_title_slide(meta, slide_text, eyebrow):
    """Slide 1 gets the special hero treatment matching the template's
    pre-built slide1 markup: eyebrow, big title with an accent span,
    italic subtitle, divider, intro paragraph."""
    lines = [l for l in slide_text.splitlines() if l.strip()]
    title_line = ''
    subtitle = ''
    intro_lines = []
    for line in lines:
        if line.startswith('# '):
            title_line = line[2:].strip()
        elif line.startswith('*') and line.endswith('*') and not subtitle:
            subtitle = line.strip('*').strip()
        elif title_line:
            intro_lines.append(line)
    if '::' in title_line:
        part_one, part_two = title_line.split('::', 1)
        part_one, part_two = part_one.strip(), part_two.strip()
    else:
        part_one, part_two = title_line, ''
    intro = ' '.join(intro_lines).strip()

    html = f'''<div class="slide-container slide-active" id="slide1">
    <div class="text-center max-w-4xl mx-auto space-y-5 animate-fade-up px-4">'''
    if eyebrow:
        html += f'''
        <div class="inline-flex items-center gap-2 px-3 py-1 bg-sky-500/5 border border-sky-500/15 rounded-full text-xs text-sky-400 font-mono tracking-wider">
            <i class="fa-solid fa-seedling"></i> {escape_html(eyebrow.upper())}
        </div>'''
    html += f'''
        <h1 class="text-5xl md:text-7xl font-serif font-light text-slate-100 leading-tight">
            {escape_html(part_one)}{' <strong class="text-sky-400 font-bold">' + escape_html(part_two) + '</strong>' if part_two else ''}
        </h1>'''
    if subtitle:
        html += f'''
        <p class="font-serif italic text-lg md:text-2xl text-sky-400 font-light max-w-3xl mx-auto">
            {escape_html(subtitle)}
        </p>'''
    html += '''
        <div class="h-0.5 w-24 bg-sky-400 mx-auto my-5"></div>'''
    if intro:
        html += f'''
        <p class="text-slate-300 text-sm max-w-2xl mx-auto">
            {escape_html(intro)}
        </p>'''
    html += '''
    </div>
</div>'''
    return html


def render_body_slide(index, slide_text):
    """Slides after the first get a simple, generously-spaced layout:
    a heading and one or more paragraphs. This is the minimal-viable
    body renderer — see REFERENCE.md for how to hand-extend a specific
    slide with richer blocks (stat grids, tabs, etc.) without touching
    this script."""
    lines = slide_text.splitlines()
    heading = ''
    paragraphs = []
    current = []
    for line in lines:
        if line.startswith('## '):
            heading = line[3:].strip()
        elif line.strip() == '':
            if current:
                paragraphs.append(' '.join(current))
                current = []
        else:
            current.append(line.strip())
    if current:
        paragraphs.append(' '.join(current))

    html = f'''<div class="slide-container slide-inactive" id="slide{index}">
    <div class="max-w-4xl mx-auto space-y-6 animate-fade-up px-4 w-full">'''
    if heading:
        html += f'''
        <h2 class="text-3xl md:text-4xl font-serif font-bold text-slate-100">{escape_html(heading)}</h2>
        <div class="h-0.5 w-16 bg-sky-400"></div>'''
    for p in paragraphs:
        html += f'''
        <p class="text-slate-300 text-base leading-relaxed">{escape_html(p)}</p>'''
    html += '''
    </div>
</div>'''
    return html


def escape_html(s):
    return (s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
             .replace('"', '&quot;'))


def slide_title_for_index(index, slide_text, fallback):
    """The sidebar/header title for a slide: the first heading found,
    or a fallback like 'Slide 3' if the author left it untitled."""
    m = re.search(r'^#{1,2}\s+(.+)$', slide_text, re.MULTILINE)
    if m:
        title = m.group(1).split('::')[0].strip()
        return title
    return fallback


def build(input_path: Path, output_path: Path, template_path: Path):
    raw = input_path.read_text(encoding='utf-8')
    meta, body = parse_frontmatter(raw)
    slide_texts = split_slides(body)
    if not slide_texts:
        raise SystemExit('No slides found — markdown body is empty after frontmatter.')

    title = meta.get('title', 'Untitled Deck')
    short_title = meta.get('short_title', title)
    author = meta.get('author', '')
    eyebrow = meta.get('eyebrow', '')

    slide_titles = {}
    bookmark_indices = []
    slide_html_blocks = []

    for i, raw_slide in enumerate(slide_texts, start=1):
        is_bookmark, cleaned = extract_bookmark(raw_slide)
        if is_bookmark:
            bookmark_indices.append(i)
        fallback = f'Slide {i}'
        slide_titles[i] = slide_title_for_index(i, cleaned, fallback)
        if i == 1:
            slide_html_blocks.append(render_title_slide(meta, cleaned, eyebrow))
        else:
            slide_html_blocks.append(render_body_slide(i, cleaned))

    total_slides = len(slide_texts)
    titles_js = ',\n        '.join(
        f'{i}: "{slide_titles[i].replace(chr(34), chr(39))}"' for i in range(1, total_slides + 1)
    )
    bookmarks_js = ', '.join(str(i) for i in bookmark_indices)

    template_html = template_path.read_text(encoding='utf-8')

    # Replace the single example slide block with the full generated set.
    slide_block_pattern = re.compile(
        r'<!-- ====================================================\n'
        r'\s*SLIDE TEMPLATE.*?<!-- Add slide2, slide3, \.\.\. here, each slide-container slide-inactive -->',
        re.DOTALL,
    )
    joined_slides = '\n\n                '.join(slide_html_blocks)
    new_html = slide_block_pattern.sub(joined_slides, template_html)
    if new_html == template_html:
        raise SystemExit('Could not find the slide-template placeholder block in the template — '
                          'has deck-template.html been hand-edited? See REFERENCE.md.')

    # Controller script: totalSlides, slideTitles, bookmarkSlides.
    # These must run BEFORE the generic {{...}} placeholder substitution
    # below, since the slideTitles block-match contains the literal
    # {{FIRST_SLIDE_TITLE}} placeholder text and would no longer match
    # once that placeholder has already been substituted.
    new_html = new_html.replace('const totalSlides = 1;', f'const totalSlides = {total_slides};')
    new_html = new_html.replace(
        'const slideTitles = {\n        1: "{{FIRST_SLIDE_TITLE}}"\n        // 2: "...", 3: "...", etc — must have exactly totalSlides entries\n    };',
        f'const slideTitles = {{\n        {titles_js}\n    }};'
    )
    new_html = new_html.replace(
        'const bookmarkSlides = [];',
        f'const bookmarkSlides = [{bookmarks_js}];'
    )
    new_html = new_html.replace(
        '<span id="slide-progress-text">Slide 1 of 1</span>',
        f'<span id="slide-progress-text">Slide 1 of {total_slides}</span>'
    )

    # Metadata placeholders (must run AFTER the slideTitles block-replace
    # above, for the reason noted there).
    replacements = {
        '{{DECK_TITLE}}': title,
        '{{DECK_SHORT_TITLE}}': short_title,
        '{{DECK_AUTHOR}}': author,
        '{{DECK_AUTHOR_LABEL}}': f'Author: {author}' if author else '',
        '{{FIRST_SLIDE_TITLE}}': slide_titles[1],
        '{{EYEBROW_TEXT}}': '',   # baked directly into slide1 HTML already
        '{{TITLE_PART_ONE}}': '',
        '{{TITLE_PART_TWO_ACCENT}}': '',
        '{{SUBTITLE}}': '',
        '{{INTRO_PARAGRAPH}}': '',
    }
    for placeholder, value in replacements.items():
        new_html = new_html.replace(placeholder, escape_html(value) if value else '')

    output_path.write_text(new_html, encoding='utf-8')
    print(f'Built {output_path} — {total_slides} slide(s).')


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('input_md', type=Path)
    parser.add_argument('output_html', type=Path)
    parser.add_argument('--template', type=Path, default=Path(__file__).parent.parent / 'deck-template.html')
    args = parser.parse_args()

    if not args.input_md.exists():
        raise SystemExit(f'Input file not found: {args.input_md}')
    if not args.template.exists():
        raise SystemExit(f'Template not found: {args.template}')

    build(args.input_md, args.output_html, args.template)


if __name__ == '__main__':
    main()
