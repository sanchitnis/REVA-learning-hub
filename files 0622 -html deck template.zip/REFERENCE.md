# Learning Deck — Markdown Authoring Reference

## File Structure

```markdown
---
title: Full title — shown in browser tab and the header chip
short_title: Short title — shown in the sidebar header (omit to reuse title)
author: Name shown under the short title and in the footer
eyebrow: Small tag line above the hero title on slide 1 (optional)
---

# Slide One Title :: Accent Part

*Italic subtitle line, on its own line, wrapped in single asterisks*

Intro paragraph for slide one. Plain text.

===bookmark===

---

## Slide Two Title

Body paragraph one.

Body paragraph two — a blank line above starts a new paragraph.

---

## Slide Three Title

...
```

## Rules

- **Frontmatter** is the block between the first two `---` lines at the very top of the file. Only simple `key: value` lines are supported — no nested YAML, no lists. This keeps the parser dependency-free.
- **Slide separator** is a line containing only `---` (three or more hyphens), on its own line, with a blank line on either side. This is distinct from the frontmatter delimiter, which is already consumed before slide-splitting happens.
- **Slide 1 is always the hero/title slide** and uses a different layout than every other slide:
  - `# Title` — the `#` heading becomes the big hero title. Use `::` inside it to split into a plain part and an accent part (rendered in the sky-blue accent color): `# Physical :: AI` renders "Physical" in white and "AI" in accent.
  - An italic line (`*wrapped in asterisks*`) directly below becomes the subtitle.
  - Any plain paragraph after that becomes the intro paragraph under the divider.
- **Slides 2+ use the plain body layout**: a `##` heading, then one or more paragraphs separated by blank lines. This is intentionally minimal — see SKILL.md's "When the Minimal Renderer Isn't Enough" section if you need more than this.
- **`===bookmark===`** on its own line, anywhere in a slide, marks that slide to render with a bookmark icon in the sidebar instead of a number — use this for a slide that opens a new thematic section, the same convention the reference deck used for its four chapter-opener slides.
- **The sidebar/header title for a slide** is taken from its first heading (split at `::` if present, taking only the plain part). If a slide has no heading at all, it falls back to "Slide N".

## What Is Deliberately Not Supported (Yet)

These are real gaps, not oversights — they're the most likely next additions if a deck needs them, but adding support is a platform change (new render function + new markdown syntax), not something to work around by hand-editing output:

- Images (would need a place to put image assets relative to the output HTML)
- Lists (bulleted or numbered) inside a body slide
- The stat-tile grids, tabbed company/product cards, hotspot diagrams, and "run demo" sandboxes seen in the reference deck — these are all genuinely per-slide custom widgets in the original, not a generic block type, and are intentionally out of scope for the mechanical generator. Author them as a one-off `<script>` + HTML block appended to that specific deck's generated output instead (see SKILL.md).
- Multiple accent colors per deck (the template's accent is sky-blue throughout; a deck-specific accent would require a templated CSS variable, not yet built)

## Preserving a Hand-Added Widget Across Regeneration

If a deck has a one-off widget appended after the core controller script (per SKILL.md), regenerating that deck from markdown will overwrite the whole file and lose it, since `build_deck.py` always writes a complete fresh file. Until a more sophisticated merge step exists, the practical approach is:

1. Keep the widget's HTML/JS in a separate file alongside the deck's markdown (e.g. `mydeck.widget.html`).
2. After regenerating, manually re-append that file's content at the marked insertion point.
3. If this becomes a frequent need, that is itself a signal to propose (via `specification/`) a `--widget` flag for `build_deck.py` that does this automatically — don't build that ad hoc inside a deck's own files.

## Example

See `sample.md` alongside this reference for a complete three-slide working example, and run:

```bash
python3 scripts/build_deck.py sample.md sample-output.html
```

to see it build.
