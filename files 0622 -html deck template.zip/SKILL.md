---
name: learning-deck
description: "Use this skill to create or update an interactive single-page HTML learning deck for SrujanaSangama (a styled, slide-based reference document — distinct from a live-presentation slide deck) from markdown content. Triggers: 'build a learning deck about X', 'create developer onboarding material', 'turn this markdown into the deck format', 'update the deck for domain Y', 'regenerate the HTML deck'. The visual design is fixed (dark slate/sky theme, sidebar slide index, keyboard/touch navigation) and matches the platform's reference deck template — do not invent a different visual design. This skill is mechanical: it converts markdown to HTML deterministically and never originates content itself."
license: Internal — SrujanaSangama / REVA University
---

# Learning Deck Skill

Generates the interactive HTML learning material used across SrujanaSangama's Research Loop output (see `loops/research-loop.md`) and the planned developer/contributor learning thread — both the faculty-facing "how to use" material and the deeper "how this is built, and the tech background to extend it" material for contributors. One template, one visual design, many pages: a user writes markdown, this skill produces or regenerates the HTML.

## Quick Reference

| Task | Command |
|------|---------|
| Build a new deck from markdown | `python3 scripts/build_deck.py <input.md> <output.html>` |
| Regenerate an existing deck after editing its markdown | Re-run the same command — output is fully deterministic, safe to overwrite |
| See the markdown authoring contract in full | Read [REFERENCE.md](REFERENCE.md) |
| See the empty visual template directly | [deck-template.html](deck-template.html) |

## How It Works

1. The author writes a single markdown file: a short frontmatter block (title, author, eyebrow) followed by slides separated by a line containing only `---`.
2. `scripts/build_deck.py` parses the markdown, fills `deck-template.html`'s placeholders, and writes a complete, self-contained HTML file — no build step, no external dependency beyond CDN-loaded fonts/Tailwind/Font Awesome (same as the source design this template was extracted from).
3. To update a deck later, edit the markdown and re-run the script. **Never hand-edit the generated HTML directly** — any manual fix will be silently lost the next time someone regenerates it from markdown. If the generated output is wrong, the fix belongs in the markdown, in `build_deck.py`, or in `deck-template.html` itself (in that order of likelihood).

## When the Minimal Renderer Isn't Enough

`build_deck.py`'s body-slide renderer is deliberately minimal — a heading plus paragraphs — because that covers most learning material. Three situations need more, and each has a different correct fix:

- **A slide needs a richer layout** (a stat grid, a tabbed comparison, a labelled diagram) that will be reused across several decks → add a new render function to `build_deck.py` and a new markdown block syntax for it, documented in `REFERENCE.md`. This is a platform change — goes through `specification/` per `CONSTITUTION.md` §6, since it changes a shared tool.
- **A slide needs a one-off interactive widget** (a sandbox demo, a clickable hotspot diagram) that's specific to this one deck and won't recur → write it as a small, self-contained `<script>` block and append it after the core controller script in that deck's own generated HTML, per the marked insertion point near the end of `deck-template.html`. Re-running `build_deck.py` on that deck will currently overwrite this — see the note in `REFERENCE.md` on preserving a hand-added widget across regeneration.
- **The visual design itself needs to change** (new color, new chrome element) → that is a change to `deck-template.html`, which is the shared chassis for every deck. Treat it with the same care as any shared skill per `CONSTITUTION.md` — a change here affects every deck, including ones already published.

## Design Provenance

The visual design (dark slate background, sky-blue accent, Inter/Merriweather typography, sidebar slide index, footer progress dots, keyboard/touch navigation, light-mode toggle) was extracted faithfully from a reference deck provided by the Product Owner, not originated by this skill. `deck-template.html` is the source of truth for that design — see its own header comments for the exact Tailwind color tokens. Do not apply general frontend-design judgment to override this; the brief for this skill is to match the given design, not to design something new.
