---
title: Software 3.0 at SrujanaSangama
short_title: Software 3.0
author: Sanjay Chitnis
eyebrow: research notes
---

# Software :: 3.0

*A new way of building institutional software*

This deck explains why SrujanaSangama is being built primarily through natural-language specifications read directly by AI coding agents, and what that means for contributors.

===bookmark===

---

## What Software 3.0 Means Here

Instead of compiling markdown into a binary plugin, every domain folder is read directly by Claude Code, GitHub Copilot, or Google Antigravity. The specification is the program.

This is the same shift Karpathy describes: prompts and natural language become the primary artifact, with the model as the runtime.

---

## Why It Matters For Contributors

A contributor does not need to learn a plugin SDK. They need to learn how to write a clear, well-scoped markdown command file that an agent can follow reliably across three different IDEs.
